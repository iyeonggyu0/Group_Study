import styled from "styled-components";

const Footer = () => {

    return (
        <FooterBtn>Page</FooterBtn>
        
    )
}
export default Footer;

const FooterBtn = styled.button`
    width: 530px;
    height: 43px;
`