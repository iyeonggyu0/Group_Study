import styled from "styled-components";

const View = () => {

    return (
        <ViewBtn>View</ViewBtn>
        
    )
}
export default View;

const ViewBtn = styled.button`
    width: 530px;
    height: 43px;
`