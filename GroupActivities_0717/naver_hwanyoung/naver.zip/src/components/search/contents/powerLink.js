import styled from "styled-components";

const PowerLink = () => {

    return (
        <PowerLinkBtn>PowerLink</PowerLinkBtn>
        
    )
}
export default PowerLink;

const PowerLinkBtn = styled.button`
    width: 530px;
    height: 43px;
`