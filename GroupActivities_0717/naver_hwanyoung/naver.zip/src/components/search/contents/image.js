import styled from "styled-components";

const Image = () => {

    return (
        <ImageBtn>Image</ImageBtn>
        
    )
}
export default Image;

const ImageBtn = styled.button`
    width: 530px;
    height: 43px;
`