import styled from "styled-components";

const News = () => {

    return (
        <NewsBtn>News</NewsBtn>
        
    )
}
export default News;

const NewsBtn = styled.button`
    width: 530px;
    height: 43px;
`