import styled from "styled-components";

const Dictionary = () => {

    return (
        <DictionaryBtn>Basemap</DictionaryBtn>
        
    )
}
export default Dictionary;

const DictionaryBtn = styled.button`
    width: 530px;
    height: 43px;
`