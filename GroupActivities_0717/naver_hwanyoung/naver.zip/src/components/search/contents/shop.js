import styled from "styled-components";

const Shop = () => {

    return (
        <ShopBtn>Shop</ShopBtn>
        
    )
}
export default Shop;

const ShopBtn = styled.button`
    width: 530px;
    height: 43px;
`