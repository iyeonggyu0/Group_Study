import styled from "styled-components";

const Video = () => {

    return (
        <VideoBtn>Video</VideoBtn>
        
    )
}
export default Video;

const VideoBtn = styled.button`
    width: 530px;
    height: 43px;
`