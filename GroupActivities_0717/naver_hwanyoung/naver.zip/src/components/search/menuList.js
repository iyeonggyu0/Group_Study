

const MenuList = () => {

    return (
        <div>통합  동영상  어학사전  이미지  VIEW  지식IN  인플루언서  쇼핑  뉴스  지도</div>
        
    )
}
export default MenuList;

