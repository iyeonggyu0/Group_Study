import styled from "styled-components";

const Page = () => {

    return (
        <PageBtn>Page</PageBtn>
        
    )
}
export default Page;

const PageBtn = styled.button`
    width: 530px;
    height: 43px;
`